package com.example.mvltsevinc.twitchedits.Youtube;

/**
 * Static container class for holding a reference to your YouTube Developer Key.
 */
public class DeveloperKey {
    public static final String DEVELOPER_KEY = "AIzaSyAKcxM5L6oSJJSVFbE-iy5cVGgfVyEA6DM";
}
